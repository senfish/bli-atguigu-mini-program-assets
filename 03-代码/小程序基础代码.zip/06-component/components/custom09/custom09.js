// components/custom09/custom09.js
Component({

  // 组件接受的外部样式类
  externalClasses: ['extend-class'],

  /**
   * 组件的属性列表
   */
  properties: {

  },

  /**
   * 组件的初始数据
   */
  data: {

  },

  /**
   * 组件的方法列表
   */
  methods: {

  }
})
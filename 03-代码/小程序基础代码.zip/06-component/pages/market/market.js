// pages/market/market.js
Page({

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {
    console.log('🥈小程序页面 - market - onLoad')
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {
    console.log('🥈小程序页面 - market - onReady')
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {
    console.log('🥈小程序页面 - market - onShow')
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {
    console.log('🥈小程序页面 - market - onHide')
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {
    console.log('🥈小程序页面 - market - onUnload')
  }

})

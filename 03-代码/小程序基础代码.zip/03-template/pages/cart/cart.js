// cart.js
Page({

  data: {

    value: 123,
    isChecked: false,
    obj: {
      value: 123
    }

  }

})

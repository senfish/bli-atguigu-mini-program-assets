const appInstance = getApp()

Page({

  onLoad () {

    // console.log(appInstance.globalData.token)

  }

})
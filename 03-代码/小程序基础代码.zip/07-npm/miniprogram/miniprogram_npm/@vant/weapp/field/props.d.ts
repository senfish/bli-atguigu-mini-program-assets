/// <reference types="miniprogram-api-typings" />
export declare const commonProps: WechatMiniprogram.Component.PropertyOption;
export declare const inputProps: WechatMiniprogram.Component.PropertyOption;
export declare const textareaProps: WechatMiniprogram.Component.PropertyOption;

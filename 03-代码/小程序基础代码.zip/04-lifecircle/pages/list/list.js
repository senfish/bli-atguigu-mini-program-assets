// list.js
Page({

  onUnload () {
    console.log('List 页面被销毁')
  }

})